let currentMode = 'general'
let isProcessing = false
let lastResult = null

const elements = {
  promptInput: null,
  startBtn: null,
  statusDisplay: null,
  progressSteps: null,
  modeButtons: null,
  currentWebsite: null,
  apiStatus: null,
  resultLink: null,
  copyResultLink: null,
}

document.addEventListener('DOMContentLoaded', async () => {
  console.log('[BabelPrompt v4.1] Initializing...')
  
  initializeElements()
  bindEventListeners()
  await checkInitialStatus()
  chrome.runtime.onMessage.addListener(handleBackgroundMessage)
  
  console.log('[BabelPrompt v4.1] Ready')
})

function initializeElements() {
  elements.promptInput = document.getElementById('promptInput')
  elements.startBtn = document.getElementById('startBtn')
  elements.statusDisplay = document.getElementById('statusDisplay')
  elements.progressSteps = document.getElementById('progressSteps')
  elements.modeButtons = document.querySelectorAll('.mode-btn')
  elements.currentWebsite = document.getElementById('currentWebsite')
  elements.apiStatus = document.getElementById('apiStatus')
  elements.resultLink = document.getElementById('resultLink')
  elements.copyResultLink = document.getElementById('copyResultLink')
}

function bindEventListeners() {
  elements.startBtn.addEventListener('click', handleStart)
  
  elements.modeButtons.forEach(btn => {
    btn.addEventListener('click', () => switchMode(btn.dataset.mode))
  })
  
  elements.promptInput.addEventListener('keydown', (event) => {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault()
      handleStart()
    }
  })
  
  if (elements.copyResultLink) {
    elements.copyResultLink.addEventListener('click', handleCopyResult)
  }
  
  console.log('[BabelPrompt v4.1] Event listeners bound')
}

async function handleStart() {
  const prompt = elements.promptInput.value.trim()
  
  if (!prompt) {
    showNotification('请输入提示词', 'warning')
    return
  }
  
  if (isProcessing) {
    showNotification('正在处理中...', 'warning')
    return
  }
  
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })
    
    if (!tab || !tab.url) {
      showNotification('无法获取当前标签页', 'error')
      return
    }
    
    const supportedWebsites = ['chat.openai.com', 'chatgpt.com', 'gemini.google.com', 'claude.ai']
    const isSupported = supportedWebsites.some(site => tab.url.includes(site))
    
    if (!isSupported) {
      showNotification('请先打开 ChatGPT、Gemini 或 Claude', 'error')
      return
    }
    
    isProcessing = true
    elements.startBtn.disabled = true
    lastResult = null
    elements.resultLink.style.display = 'none'
    
    updateStatus('processing', '⏳', '正在处理...', '请稍候')
    showProgressSteps(true)
    setActiveStep(1)
    
    console.log('[BabelPrompt v4.1] Starting workflow, mode:', currentMode)
    
    try {
      const response = await chrome.tabs.sendMessage(tab.id, {
        type: 'PING'
      })
      
      if (!response || !response.ready) {
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          files: ['content.js']
        })
        await new Promise(r => setTimeout(r, 1000))
      }
    } catch (e) {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ['content.js']
      })
      await new Promise(r => setTimeout(r, 1000))
    }
    
    chrome.tabs.sendMessage(
      tab.id,
      {
        type: 'START_TWO_PASS_WORKFLOW',
        prompt: prompt,
        mode: currentMode
      },
      handleWorkflowResponse
    )
  } catch (error) {
    console.error('[BabelPrompt v4.1] Start failed:', error)
    showNotification('启动失败: ' + error.message, 'error')
    resetProcessingState()
  }
}

function handleWorkflowResponse(response) {
  if (chrome.runtime.lastError) {
    console.error('[BabelPrompt v4.1] Message error:', chrome.runtime.lastError)
    showNotification('无法连接到页面，请刷新后重试', 'error')
    resetProcessingState()
    return
  }
  
  if (response && response.received) {
    console.log('[BabelPrompt v4.1] Workflow started in content script')
  } else {
    showNotification('启动失败', 'error')
    resetProcessingState()
  }
}

function updateStatus(state, icon, text, detail = '') {
  const display = elements.statusDisplay
  display.className = `status-display ${state}`
  display.innerHTML = `
    <div class="status-icon">${icon}</div>
    <div class="status-text">${text}</div>
    ${detail ? `<div class="status-detail">${detail}</div>` : ''}
  `
}

function showProgressSteps(show) {
  elements.progressSteps.classList.toggle('active', show)
}

function setActiveStep(stepNum) {
  const steps = elements.progressSteps.querySelectorAll('.progress-step')
  steps.forEach((step, index) => {
    const stepN = index + 1
    step.classList.remove('active', 'completed')
    if (stepN < stepNum) {
      step.classList.add('completed')
    } else if (stepN === stepNum) {
      step.classList.add('active')
    }
  })
}

function switchMode(mode) {
  currentMode = mode
  elements.modeButtons.forEach(btn => {
    btn.classList.toggle('active', btn.dataset.mode === mode)
  })
  console.log('[BabelPrompt v4.1] Mode:', mode)
}

async function checkInitialStatus() {
  try {
    if (elements.apiStatus) {
      elements.apiStatus.innerHTML = '✅ Ready'
    }
    
    const website = await getCurrentWebsite()
    if (elements.currentWebsite) {
      if (website) {
        elements.currentWebsite.innerHTML = `✅ ${website}`
        elements.currentWebsite.style.color = '#34a853'
      } else {
        elements.currentWebsite.innerHTML = '⚠️ Open ChatGPT/Gemini/Claude'
        elements.currentWebsite.style.color = '#ea4335'
      }
    }
  } catch (error) {
    console.error('[BabelPrompt v4.1] Status check failed:', error)
  }
}

async function getCurrentWebsite() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })
    if (!tab || !tab.url) return null
    
    const websites = {
      'chat.openai.com': 'ChatGPT',
      'chatgpt.com': 'ChatGPT',
      'gemini.google.com': 'Gemini',
      'claude.ai': 'Claude',
    }
    
    for (const [url, name] of Object.entries(websites)) {
      if (tab.url.includes(url)) return name
    }
    return null
  } catch {
    return null
  }
}

function handleBackgroundMessage(message, sender, sendResponse) {
  console.log('[BabelPrompt v4.1] Received:', message.type)
  
  switch (message.type) {
    case 'WORKFLOW_STATUS':
      handleWorkflowStatus(message)
      sendResponse({ success: true })
      break
      
    case 'WORKFLOW_COMPLETE':
      handleWorkflowComplete(message)
      sendResponse({ success: true })
      break
      
    case 'WORKFLOW_ERROR':
      handleWorkflowError(message)
      sendResponse({ success: true })
      break
      
    default:
      sendResponse({ success: false })
  }
  return true
}

function handleWorkflowStatus(message) {
  const { step, description } = message
  
  console.log('[BabelPrompt v4.1] Workflow step:', step, description)
  
  const stepMap = {
    'injecting_first': 1,
    'waiting_first': 2,
    'injecting_second': 3,
    'waiting_second': 4,
  }
  
  const stepNum = stepMap[step] || 1
  setActiveStep(stepNum)
  
  const statusDetails = {
    'injecting_first': { text: '注入 Meta-Prompt...', detail: '步骤 1/2' },
    'waiting_first': { text: '等待 LLM 分析...', detail: '请稍候' },
    'injecting_second': { text: '注入优化提示词...', detail: '步骤 2/2' },
    'waiting_second': { text: '等待最终响应...', detail: '即将完成' },
  }
  
  const detail = statusDetails[step] || { text: description, detail: '' }
  updateStatus('processing', '⏳', detail.text, detail.detail)
}

function handleWorkflowComplete(message) {
  console.log('[BabelPrompt v4.1] Workflow complete')
  
  lastResult = message.result
  
  updateStatus('completed', '✅', '完成！', '结果已在 LLM 聊天中显示')
  setActiveStep(5)
  
  if (lastResult && elements.resultLink) {
    elements.resultLink.style.display = 'block'
  }
  
  showNotification('✨ 优化完成！', 'success')
  resetProcessingState()
}

function handleWorkflowError(message) {
  console.error('[BabelPrompt v4.1] Workflow error:', message.error)
  
  updateStatus('error', '❌', '出错了', message.error || '未知错误')
  showProgressSteps(false)
  showNotification('处理失败: ' + (message.error || '未知错误'), 'error')
  resetProcessingState()
}

function resetProcessingState() {
  isProcessing = false
  elements.startBtn.disabled = false
}

async function handleCopyResult() {
  if (!lastResult) {
    showNotification('没有可复制的结果', 'warning')
    return
  }
  
  try {
    await navigator.clipboard.writeText(lastResult)
    showNotification('已复制到剪贴板', 'success')
  } catch (error) {
    console.error('[BabelPrompt v4.1] Copy failed:', error)
    showNotification('复制失败', 'error')
  }
}

function showNotification(message, type = 'info') {
  const notification = document.getElementById('notification')
  notification.textContent = message
  notification.className = `toast ${type}`
  notification.style.display = 'block'
  
  setTimeout(() => {
    notification.style.display = 'none'
  }, 3000)
}

function showLoading(show) {
  const overlay = document.getElementById('loadingOverlay')
  overlay.classList.toggle('active', show)
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { handleStart, switchMode }
}
