;(function () {
  'use strict'

  let isProcessing = false
  let currentAdapter = null

  const SELECTORS = {
    'gemini.google.com': {
      input: 'textarea[placeholder*="Enter"], .ql-editor, rich-textarea, div[contenteditable="true"]',
      submit: 'button[aria-label*="Send"], button[data-id*="send"], button[type="submit"]'
    },
    'chatgpt.com': {
      input: 'textarea#prompt-textarea, div[contenteditable="true"]',
      submit: 'button[data-testid*="send"], button[aria-label*="Send"]'
    },
    'chat.openai.com': {
      input: 'textarea#prompt-textarea, div[contenteditable="true"]',
      submit: 'button[data-testid*="send"], button[aria-label*="Send"]'
    },
    'claude.ai': {
      input: 'div[contenteditable="true"], textarea',
      submit: 'button[aria-label*="Send"], button[type="submit"]'
    }
  }

  function init() {
    console.log('[BabelPrompt] Content script initialized')
    setupInputDetection()
    setupMessageListener()
    console.log('[BabelPrompt] Ready, hostname:', window.location.hostname)
  }

  function getSelectors() {
    const hostname = window.location.hostname
    for (const [domain, selectors] of Object.entries(SELECTORS)) {
      if (hostname.includes(domain.replace('.com', '').replace('.ai', '')) || 
          hostname === domain) {
        return selectors
      }
    }
    return null
  }

  function findInput() {
    const selectors = getSelectors()
    if (!selectors) return null
    
    for (const sel of selectors.input.split(', ')) {
      const el = document.querySelector(sel)
      if (el && isVisible(el)) return el
    }
    return null
  }

  function findSubmitButton() {
    const selectors = getSelectors()
    if (!selectors) return null
    
    for (const sel of selectors.submit.split(', ')) {
      const btns = document.querySelectorAll(sel)
      for (const btn of btns) {
        if (isVisible(btn) && !btn.disabled) return btn
      }
    }
    return null
  }

  function isVisible(el) {
    const rect = el.getBoundingClientRect()
    return rect.width > 0 && rect.height > 0 && 
           getComputedStyle(el).display !== 'none' &&
           getComputedStyle(el).visibility !== 'hidden'
  }

  async function typeText(element, text) {
    element.focus()
    element.click()
    
    if (element.tagName === 'TEXTAREA' || element.tagName === 'INPUT') {
      element.value = ''
      element.value = text
      element.dispatchEvent(new Event('input', { bubbles: true }))
      element.dispatchEvent(new Event('change', { bubbles: true }))
    } else {
      element.focus()
      document.execCommand('selectAll', false, null)
      document.execCommand('delete', false, null)
      await sleep(50)
      document.execCommand('insertText', false, text)
      element.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: text }))
    }
    
    await sleep(100)
  }

  async function submitForm() {
    const btn = findSubmitButton()
    if (btn) {
      btn.click()
      await sleep(500)
      return true
    }
    
    const input = findInput()
    if (input) {
      input.dispatchEvent(new KeyboardEvent('keydown', {
        key: 'Enter', code: 'Enter', keyCode: 13, bubbles: true
      }))
      await sleep(500)
      return true
    }
    
    return false
  }

  async function captureResponse(timeout = 30000) {
    const startTime = Date.now()
    let lastLength = 0
    let stableCount = 0
    
    while (Date.now() - startTime < timeout) {
      await sleep(1000)
      
      const responseElements = document.querySelectorAll('[data-test-id*="conversation-turn"], .response-container, .model-response, [data-testid*="conversation"]')
      let currentLength = 0
      
      for (const el of responseElements) {
        currentLength += el.textContent.length
      }
      
      if (currentLength > 0 && currentLength === lastLength) {
        stableCount++
        if (stableCount >= 3) {
          const lastEl = responseElements[responseElements.length - 1]
          return lastEl ? lastEl.textContent.trim() : ''
        }
      } else {
        stableCount = 0
      }
      
      lastLength = currentLength
    }
    
    return ''
  }

  function generateFirstPassPrompt(originalPrompt, mode = 'general') {
    const modeInstructions = {
      general: '请帮我分析并改进这个提示词，使其更加清晰、具体和有效：',
      code: '请帮我优化这个编程相关的提示词，使其更加结构化和专业：',
      creative: '请帮我优化这个创意写作的提示词，使其更具启发性：',
      business: '请帮我优化这个商业相关的提示词，使其更加专业和有说服力：'
    }
    
    const instruction = modeInstructions[mode] || modeInstructions.general
    
    return `${instruction}

原始提示词：${originalPrompt}

请按照以下格式输出优化后的提示词：
1. 分析原始提示词的问题
2. 建议改进方向
3. 给出优化后的提示词`
  }

  function generateSecondPassPrompt(originalPrompt, firstResponse, mode = 'general') {
    return `基于以下分析，请直接回答用户的原始问题：

原始问题：${originalPrompt}

分析建议：${firstResponse.substring(0, 500)}

请直接给出完整的回答：`
  }

  function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms))
  }

  function setupInputDetection() {
    const style = document.createElement('style')
    style.textContent = `
      .babelprompt-highlighted {
        box-shadow: 0 0 0 2px rgba(139, 92, 246, 0.3) !important;
      }
      .babelprompt-highlighted:focus {
        box-shadow: 0 0 0 2px rgba(139, 92, 246, 0.5) !important;
      }
    `
    document.head.appendChild(style)
    
    detectInputs()
    const observer = new MutationObserver(() => setTimeout(detectInputs, 500))
    observer.observe(document.body, { childList: true, subtree: true })
  }

  function detectInputs() {
    const input = findInput()
    if (input && !input.classList.contains('babelprompt-highlighted')) {
      input.classList.add('babelprompt-highlighted')
    }
  }

  function setupMessageListener() {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      switch (message.type) {
        case 'PING':
          sendResponse({ ready: true })
          break
          
        case 'START_TWO_PASS_WORKFLOW':
          handleTwoPassWorkflow(message, sendResponse)
          return true
          
        case 'INJECT_PROMPT':
          handleInjectPrompt(message, sendResponse)
          return true
          
        default:
          sendResponse({ success: false, error: 'Unknown message type' })
      }
      return true
    })
  }

  async function handleInjectPrompt(message, sendResponse) {
    try {
      const input = findInput()
      if (!input) {
        sendResponse({ success: false, error: 'No input field found' })
        return
      }
      
      await typeText(input, message.prompt || message.text)
      sendResponse({ success: true })
    } catch (error) {
      sendResponse({ success: false, error: error.message })
    }
  }

  async function handleTwoPassWorkflow(message, sendResponse) {
    if (isProcessing) {
      sendResponse({ received: false, error: 'Already processing' })
      return
    }

    sendResponse({ received: true })
    isProcessing = true

    const { prompt, mode = 'general' } = message

    try {
      const firstPassPrompt = generateFirstPassPrompt(prompt, mode)
      const input = findInput()
      
      if (!input) {
        throw new Error('No input field found')
      }

      await typeText(input, firstPassPrompt)
      await sleep(500)
      
      const submitted = await submitForm()
      if (!submitted) {
        throw new Error('Failed to submit')
      }

      sendStatusUpdate('waiting_first', 'Waiting for LLM analysis...')
      
      await sleep(3000)
      const firstResponse = await captureResponse(60000)

      if (!firstResponse) {
        sendStatusUpdate('error', 'No response captured')
        throw new Error('No response captured')
      }

      sendStatusUpdate('injecting_second', 'Injecting optimized prompt...')
      
      await sleep(2000)
      
      const secondPassPrompt = generateSecondPassPrompt(prompt, firstResponse, mode)
      const input2 = findInput()
      
      if (!input2) {
        throw new Error('No input field found for second pass')
      }

      await typeText(input2, secondPassPrompt)
      await sleep(500)
      
      const submitted2 = await submitForm()
      if (!submitted2) {
        throw new Error('Failed to submit second pass')
      }

      sendStatusUpdate('completed', 'Done! Result displayed in LLM chat')
      
      chrome.runtime.sendMessage({
        type: 'WORKFLOW_COMPLETE',
        success: true,
        result: 'Two-pass workflow completed successfully'
      })

    } catch (error) {
      console.error('[BabelPrompt] Workflow error:', error)
      
      chrome.runtime.sendMessage({
        type: 'WORKFLOW_ERROR',
        error: error.message
      })
    } finally {
      isProcessing = false
    }
  }

  function sendStatusUpdate(status, message) {
    console.log(`[BabelPrompt] Status: ${status} - ${message}`)
    chrome.runtime.sendMessage({
      type: 'WORKFLOW_STATUS',
      status: status,
      message: message
    }).catch(() => {})
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init)
  } else {
    init()
  }
})()
