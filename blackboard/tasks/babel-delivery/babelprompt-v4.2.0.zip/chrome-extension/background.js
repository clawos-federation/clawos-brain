// Background service worker for BabelPrompt extension v3.0
// This script handles Side Panel initialization and API proxy

console.log('BabelPrompt background service worker loading...')

// ========================================
// Extension Initialization
// ========================================

// Initialize Side Panel when extension is installed
chrome.runtime.onInstalled.addListener(() => {
  console.log('BabelPrompt extension installed')

  // Set Side Panel to open when extension icon is clicked
  if (chrome.sidePanel && chrome.sidePanel.setPanelBehavior) {
    chrome.sidePanel
      .setPanelBehavior({ openPanelOnActionClick: true })
      .catch(error => {
        console.error('Failed to set panel behavior:', error)
      })
  }
})

// Handle extension icon click (fallback for older Chrome versions)
chrome.action.onClicked.addListener(async tab => {
  console.log('Extension icon clicked')
  try {
    if (chrome.sidePanel && chrome.sidePanel.open) {
      await chrome.sidePanel.open({ windowId: tab.windowId })
    } else {
      console.warn('SidePanel API not available - using default behavior')
    }
  } catch (error) {
    console.error('Failed to open side panel:', error)
  }
})

// Log when Side Panel is opened/closed (if available)
// 使用更安全的可选链式调用
try {
  if (chrome.sidePanel?.onShown) {
    chrome.sidePanel.onShown.addListener(() => {
      console.log('BabelPrompt Side Panel opened')
    })
  }

  if (chrome.sidePanel?.onHidden) {
    chrome.sidePanel.onHidden.addListener(() => {
      console.log('BabelPrompt Side Panel closed')
    })
  }
} catch (error) {
  console.warn('SidePanel event listeners not available:', error.message)
}

// ========================================
// Message Handling
// ========================================

// Listen for messages from side panel and content scripts
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('Background received message:', message.type)

  switch (message.type) {
    // Basic operations
    case 'GET_CURRENT_TAB':
      getCurrentTab(sendResponse)
      return true // Keep message channel open for async response

    case 'TEST_CONNECTION':
      sendResponse({
        success: true,
        message: 'BabelPrompt extension is working!',
      })
      break

    // v3.0 new message handlers
    case 'SWITCH_MODE':
      handleSwitchMode(message.mode)
        .then(() => sendResponse({ success: true }))
        .catch(error => sendResponse({ success: false, error: error.message }))
      return true

    case 'CLEAR_INPUT':
      handleClearInput()
        .then(() => sendResponse({ success: true }))
        .catch(error => sendResponse({ success: false, error: error.message }))
      return true

    case 'OPEN_HISTORY':
      handleOpenPage('history.html')
        .then(() => sendResponse({ success: true }))
        .catch(error => sendResponse({ success: false, error: error.message }))
      return true

    case 'OPEN_FAVORITES':
      handleOpenPage('favorites.html')
        .then(() => sendResponse({ success: true }))
        .catch(error => sendResponse({ success: false, error: error.message }))
      return true

    case 'OPEN_TEMPLATES':
      handleOpenPage('templates.html')
        .then(() => sendResponse({ success: true }))
        .catch(error => sendResponse({ success: false, error: error.message }))
      return true

    case 'OPEN_BATCH':
      handleOpenPage('batch.html')
        .then(() => sendResponse({ success: true }))
        .catch(error => sendResponse({ success: false, error: error.message }))
      return true

    case 'OPEN_SIDEPANEL':
      handleOpenSidePanel(sender)
        .then(() => sendResponse({ success: true }))
        .catch(error => sendResponse({ success: false, error: error.message }))
      return true

    case 'OPEN_SETTINGS':
      handleOpenSettings()
        .then(() => sendResponse({ success: true }))
        .catch(error => sendResponse({ success: false, error: error.message }))
      return true

    case 'WORKFLOW_STATUS':
    case 'WORKFLOW_COMPLETE':
    case 'WORKFLOW_ERROR':
      forwardToSidePanel(message)
        .then(() => sendResponse({ success: true }))
        .catch(error => sendResponse({ success: false, error: error.message }))
      return true

    default:
      console.log('Unknown message type:', message.type)
      sendResponse({
        success: false,
        error: 'Unknown message type: ' + message.type,
      })
  }
})

// ========================================
// Command Handlers (Global Shortcuts)
// ========================================

// Handle keyboard commands from manifest.json
if (chrome.commands) {
  chrome.commands.onCommand.addListener(async command => {
    console.log('Command received:', command)

    switch (command) {
      case 'inject':
        await handleInjectCommand()
        break

      default:
        console.log('Unknown command:', command)
    }
  })
}

// Handle inject command (Ctrl+Shift+I)
async function handleInjectCommand() {
  try {
    // Send message to side panel to trigger injection
    chrome.runtime.sendMessage({
      type: 'TRIGGER_INJECT',
    })
  } catch (error) {
    console.error('Failed to trigger inject:', error)
  }
}

// ========================================
// Helper Functions
// ========================================

// Get current tab information
async function getCurrentTab(sendResponse) {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })
    sendResponse({
      success: true,
      tab: {
        id: tab.id,
        url: tab.url,
        title: tab.title,
      },
    })
  } catch (error) {
    sendResponse({
      success: false,
      error: error.message,
    })
  }
}

// Handle mode switch (1-8 keys)
async function handleSwitchMode(modeNumber) {
  try {
    const modes = [
      'general',
      'code',
      'creative',
      'business',
      'academic',
      'teaching',
      'analysis',
      'translation',
    ]
    const mode = modes[modeNumber - 1]

    if (mode) {
      // Send message to side panel
      chrome.runtime.sendMessage({
        type: 'SET_MODE',
        mode: mode,
      })
    }
  } catch (error) {
    console.error('Failed to switch mode:', error)
  }
}

// Handle clear input
async function handleClearInput() {
  try {
    chrome.runtime.sendMessage({
      type: 'CLEAR_INPUT',
    })
  } catch (error) {
    console.error('Failed to clear input:', error)
  }
}

// Handle open page (generic helper)
async function handleOpenPage(url) {
  try {
    await chrome.tabs.create({ url: url })
  } catch (error) {
    console.error('Failed to open page:', url, error)
    throw error
  }
}

async function handleOpenSidePanel(sender) {
  try {
    let windowId
    if (sender.tab && sender.tab.windowId) {
      windowId = sender.tab.windowId
    } else {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })
      windowId = tab.windowId
    }

    if (chrome.sidePanel && chrome.sidePanel.open) {
      await chrome.sidePanel.open({ windowId })
      console.log('Side panel opened successfully')
    } else {
      console.warn('SidePanel API not available')
      throw new Error('SidePanel API not available in this Chrome version')
    }
  } catch (error) {
    console.error('Failed to open side panel:', error)
    throw error
  }
}

// Handle open settings
async function handleOpenSettings() {
  try {
    if (chrome.runtime.openOptionsPage) {
      await chrome.runtime.openOptionsPage()
    } else {
      await chrome.tabs.create({ url: 'settings.html' })
    }
  } catch (error) {
    console.error('Failed to open settings:', error)
    throw error
  }
}

async function forwardToSidePanel(message) {
  try {
    await chrome.runtime.sendMessage(message)
    console.log('Message forwarded to side panel:', message.type)
  } catch (error) {
    console.log('Sidepanel not open or error:', error.message)
  }
}

console.log('BabelPrompt background service worker initialized (v3.0)')
